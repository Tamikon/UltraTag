﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pyatnashki
{
    public partial class Form15 : Form
    {
        Game game;
        public Form15()
        {
            InitializeComponent();
            game = new Game(4);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            int position = Convert.ToInt16(((Button)sender).Tag);
            game.Shift(position);
            Refresh();
            if (game.Check())
            {
                MessageBox.Show("Жоская победа");
                begin();
            }
        }


            private Button button (int position)
        {
            switch (position)
            {
                case 0: return button0;
                case 1: return button1;
                case 2: return button2;
                case 3: return button3;
                case 4: return button4;
                case 5: return button5;
                case 6: return button6;
                case 7: return button7;
                case 8: return button8;
                case 9: return button9;
                case 10: return button10;
                case 11: return button11;
                case 12: return button12;
                case 13: return button13;
                case 14: return button14;
                case 15: return button15;
                default: return null;
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void начатьИгруToolStripMenuItem_Click(object sender, EventArgs e)
        {
            begin();
        }

        private void begin()
        {
            game.Start();
            for (int j = 0; j < 100; j++)
                game.ShiftRandom();
            Refresh();
        }

        private void Refresh()
        {
            for (int pos = 0; pos < 16; pos++)
            {
                int num = game.GetNum(pos);
                button(pos).Text = num.ToString();
                button(pos).Visible = (num > 0);
            }

        }

        private void Form15_Load(object sender, EventArgs e)
        {
            begin();
        }
    }
}
